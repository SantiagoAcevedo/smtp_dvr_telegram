// smtp.js
const ewelink = require('ewelink-api');
var fs = require('fs');
const https = require('https');
const {SMTPServer} = require('smtp-server');
const parser = require("mailparser").simpleParser
const { Telegraf } = require('telegraf')

const BOT_TOKEN = '5474616559:AAFsX8Rd6CPgMtbEYZ2Nycn-xCofa7Mk7OQ';
const chatId = '-1001694122886'; //id do canal

const app = new Telegraf(BOT_TOKEN);

console.log('Sistema Iniciado!')
app.telegram.sendMessage(chatId, 'BOT INICIADO!');

let lasttime=0;
const server = new SMTPServer({
    // disable STARTTLS to allow authentication in clear text mode
    disabledCommands: ['STARTTLS'],
    authMethods: ['PLAIN', 'LOGIN', 'CRAM-MD5'],
    logger: false,
    onAuth(auth, session, callback) {
        let username = 'santiago';
        let password = 'santiago';

        // check username and password
        if (
            auth.username === username &&
            (auth.method === 'CRAM-MD5'
                ? auth.validatePassword(password) // if cram-md5, validate challenge response
                : auth.password === password) // for other methods match plaintext passwords
        ) {
            return callback(null, {
                user: 'userdata' // value could be an user id, or an user object etc. This value can be accessed from session.user afterwards
            });
        }

        return callback(new Error('Authentication failed'));
    },
    onData(stream, session, callback){
        parser(stream, {}, (err, parsed) => {
            //console.log(parsed)
            function myFunction(item) {
                fs.writeFile('img/'+item.filename, item.content, (err) => {
                    if (err)
                        console.log(err);
                    else {
                        console.log("Arquivo "+item.filename+" salvo\n");
                        //console.log("Erro ao salvar imagem: "+item.filename);
                    }
                });
                app.telegram.sendPhoto(chatId, { source: 'img/'+item.filename })
				fs.unlink('img/'+item.filename, (err) => {
				  if (err) {
					console.error(err)
					return
				  }
				  //file removed
				})
            }
            if (err)
                console.log("Error:" , err)
           // console.log(parsed)
            //console.log(parsed)
            //let img = encodeURI(parsed.attachments);
            let fix = encodeURI(parsed.text);
            if(parsed.attachments.length > 0){
                parsed.attachments.forEach(myFunction)
                app.telegram.sendMessage(chatId, parsed.text);
            } else if (parsed.text.includes('Perda')) {
                app.telegram.sendMessage(chatId, parsed.text);
                if(Date.now() > lasttime ){
                    const connection = new ewelink({
                        email: 'perez320@gmail.com',
                        password: '2113853211',
                        region:'us'
                    });
                   // let troca = connection.toggleDevice('10011dc627');
                    //console.log(troca);
                    function desligar() {
                        connection.setDevicePowerState('10011dc627', 'off');
                        console.log('Comando desligar enviado!')
                    }
                    function ligar() {
                        connection.setDevicePowerState('10011dc627', 'on');
                        console.log('Comando ligar enviado!')
                    }
                    setTimeout(desligar, 5000);
                    setTimeout(ligar, 10000);
                    lasttime=Date.now()+200000;
                    console.log(Date.now()+' / '+lasttime);
                }else{
                    console.log('Comando Ja enviado, aguardando!')
                }
                console.log(lasttime);
            }else{
                //console.log(parsed)
            }

            //console.log('DEBUG::: '+parsed.subject)
            stream.on("end", callback)
        })
        stream.pipe(process.stdout); // print message to console
        stream.on('end', callback);
    },
});
server.listen(587, '208.167.242.124');