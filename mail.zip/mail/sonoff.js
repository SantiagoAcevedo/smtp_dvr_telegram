const ewelink = require('ewelink-api');

(async () => {

    const connection = new ewelink({
        email: 'perez320@gmail.com',
        password: '2113853211',
        region:'us'
    });

    /* get all devices */
    //const devices = await connection.getDevices();
    //console.log(devices);

    await connection.toggleDevice('10011dc627');

})();
